# Import necessary libraries
import argparse
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import roc_auc_score
from scipy.sparse import hstack, csr_matrix

def load_data(train_path, test_path):
    """
    Load training and testing datasets.
    Drops NaN values from the 'Label' column in training data.
    """
    train = pd.read_csv(train_path).dropna(subset=['Label']).reset_index(drop=True)
    test = pd.read_csv(test_path)
    return train, test, train['Label'].values

def compute_aa_feats(seq):
    """
    Compute amino acid composition features for a given sequence.
    Features include frequency of each amino acid and fraction of polar, nonpolar, basic, and acidic residues.
    """
    aa = "ACDEFGHIKLMNPQRSTVWY"  # Standard amino acids
    prop = {
        'polar': "DERKQNHCSTY", 'nonpolar': "AGILMFPWV",
        'basic': "KRH", 'acidic': "DE"
    }
    seq = seq.upper()
    length = max(len(seq), 1)  # Prevent division by zero
    feats = {a: seq.count(a) / length for a in aa}  # Frequency of each amino acid
    feats.update({f'frac_{k}': sum(seq.count(x) for x in v) / length for k, v in prop.items()})  # Fraction properties
    feats['seq_len'] = length  # Sequence length feature
    return feats

def build_aa_df(df, col):
    """
    Create a DataFrame of amino acid composition features for all sequences in a given column.
    """
    return pd.DataFrame([compute_aa_feats(seq) for seq in df[col].astype(str)])

def extract_tfidf(train, test, col1, col2):
    """
    Extract TF-IDF features from sequence data using character n-grams (1 to 3).
    """
    vec = TfidfVectorizer(analyzer='char', ngram_range=(1, 3))
    return vec.fit_transform(train[col1].astype(str)), vec.transform(test[col2].astype(str))

def train_lgb(X, y):
    """
    Train a LightGBM model using grid search for hyperparameter tuning.
    """
    param_grid = {'num_leaves': [31, 50], 'max_depth': [10, 20], 'learning_rate': [0.01, 0.05], 'n_estimators': [300, 500]}
    gs = GridSearchCV(lgb.LGBMClassifier(random_state=42), param_grid, scoring='roc_auc', cv=3, n_jobs=-1, verbose=1)
    gs.fit(X, y)
    return gs.best_estimator_

def get_oof_preds(model, X, y, X_test, n_folds=5):
    """
    Perform out-of-fold (OOF) predictions using cross-validation.
    Returns predictions for both training and test sets.
    """
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    oof_train, oof_test = np.zeros(X.shape[0]), np.zeros((X_test.shape[0], n_folds))
    
    for i, (tr_idx, val_idx) in enumerate(skf.split(X, y)):
        model.fit(X[tr_idx], y[tr_idx])
        oof_train[val_idx] = model.predict_proba(X[val_idx])[:, 1]  # Probability estimates for validation set
        oof_test[:, i] = model.predict_proba(X_test)[:, 1]  # Probability estimates for test set
    
    return oof_train, oof_test.mean(axis=1)

def main(train_path, test_path, output_path):
    """
    Main function to execute the pipeline: load data, extract features, train models, and generate predictions.
    """
    # Load data
    train, test, y_train = load_data(train_path, test_path)
    
    # Extract TF-IDF features
    X_train_tfidf, X_test_tfidf = extract_tfidf(train, test, '# Sequence', ' Sequence')
    
    # Extract amino acid composition features
    X_train_aa, X_test_aa = build_aa_df(train, '# Sequence'), build_aa_df(test, ' Sequence')
    
    # Combine features
    X_train, X_test = hstack([X_train_tfidf, csr_matrix(X_train_aa.values)]), hstack([X_test_tfidf, csr_matrix(X_test_aa.values)])
    
    # Train base models
    lgb_model = train_lgb(X_train, y_train)
    lr_model = LogisticRegression(solver='liblinear', max_iter=1000, random_state=42)
    rf_model = RandomForestClassifier(n_estimators=300, max_depth=20, random_state=42)
    
    # Generate out-of-fold predictions for stacking
    lgb_oof_train, lgb_oof_test = get_oof_preds(lgb_model, X_train, y_train, X_test)
    lr_oof_train, lr_oof_test = get_oof_preds(lr_model, X_train, y_train, X_test)
    rf_oof_train, rf_oof_test = get_oof_preds(rf_model, X_train, y_train, X_test)
    
    # Create meta-model training data
    X_meta_train = np.vstack((lgb_oof_train, lr_oof_train, rf_oof_train)).T
    X_meta_test = np.vstack((lgb_oof_test, lr_oof_test, rf_oof_test)).T
    
    # Train meta-model
    meta_model = LogisticRegression(solver='liblinear', max_iter=1000, random_state=42)
    meta_model.fit(X_meta_train, y_train)
    
    # Evaluate meta-model performance
    print("Meta-model training AUC:", roc_auc_score(y_train, meta_model.predict_proba(X_meta_train)[:, 1]))
    
    # Save predictions to output file
    pd.DataFrame({'# ID': test['# ID'], 'Label': meta_model.predict_proba(X_meta_test)[:, 1]}).to_csv(output_path, index=False)
    print(f"Predictions saved to '{output_path}'")


# Parse command-line arguments for input file paths and output file location, then execute the main function
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Protein Classification")
    parser.add_argument('--train', type=str, required=True, help='Path to training dataset')
    parser.add_argument('--test', type=str, required=True, help='Path to testing dataset')
    parser.add_argument('--output', type=str, default='submission.csv', help='Output file path')
    args = parser.parse_args()
    main(args.train, args.test, args.output)